// 회원
// 번호, 이름
let user = {};

// 게시글
// 번호, 제목, 내용
let post = { user: user };

// 좋아요
// 번호
let like = { user: user, post: post };

// 고수들을 위한 숙제
// 중고차 시장에서 다음과 같은 데이터가 필요하다.

// 자동차
// 차주
