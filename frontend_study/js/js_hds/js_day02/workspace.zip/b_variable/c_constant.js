const ERROR_CODE = 404;
console.error(ERROR_CODE);
